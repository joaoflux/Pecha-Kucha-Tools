<?php 
$applicationPath = "../../../apps-legacy/event-reader/";
include $applicationPath.'index.php';
?>