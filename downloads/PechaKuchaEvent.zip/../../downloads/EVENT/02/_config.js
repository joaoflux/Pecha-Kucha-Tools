var speaker = "Speaker Name";
var topic = "Presentaion Title";
var date = "01.01.1970";
var delay_in = "";
var delay_out = "";
var link = "http://pechakucha.de";