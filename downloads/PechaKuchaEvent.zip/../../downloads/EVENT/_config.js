var event="Title of Event";
var date="01.01.1970";
var place="Place where event took place";
var pause1="";
var pause2="";
var count="2";