<?php 
$applicationPath = "../../apps-legacy/event-player/";
include $applicationPath.'index.php';
?>