# Example Event

- Create a copy of this directory and name it as you like
- Edit the file _config.js and _config.txt (_config.txt files are currently only used by the event creator, not by event player and single player. This redundancy will be removed soon.). Enter event title, place, date and the number of presentations in both files.
- Create subdirectories for all presentations of the event an name them 01, 02, 03, ... 
- Each subdirectory must contain _config.js and _config.txt. Enter speaker name, title, date, delay_in, delay_out (deprecated) and a link in both files.

